// layout.js — monta header/footer dinâmicos em qualquer página pública que
// tenha <div id="site-header"></div> e <div id="site-footer"></div>.

async function renderLayout(activePage) {
  const headerEl = document.getElementById('site-header');
  const footerEl = document.getElementById('site-footer');
  if (!headerEl && !footerEl) return;

  let settings = {};
  let categories = [];
  try {
    const [s, c] = await Promise.all([API.get('/api/settings'), API.get('/api/categories')]);
    settings = s.settings || {};
    categories = c.categories || [];
  } catch { /* segue com defaults */ }

  const storeName = settings.store_name || 'TN Zone';

  if (headerEl) {
    headerEl.innerHTML = `
      <header class="site-header">
        <div class="header-inner container">
          <a href="/" class="logo">
            ${settings.logo_url ? `<img src="${settings.logo_url}" alt="${escapeHtml(storeName)}">` : '<span class="dot"></span>'}
            ${escapeHtml(storeName)}
          </a>
          <nav class="main-nav">
            <a href="/" class="${activePage === 'home' ? 'active' : ''}">Início</a>
            <a href="/catalogo" class="${activePage === 'catalogo' ? 'active' : ''}">Catálogo</a>
            ${categories.slice(0, 4).map(c => `<a href="/catalogo?category=${encodeURIComponent(c.slug)}">${escapeHtml(c.name)}</a>`).join('')}
          </nav>
          <div class="header-actions">
            <a href="/catalogo" class="btn btn-ghost btn-sm">Ver catálogo</a>
          </div>
        </div>
      </header>
    `;
  }

  if (footerEl) {
    footerEl.innerHTML = `
      <footer class="site-footer">
        <div class="container">
          <div class="footer-grid">
            <div class="footer-col">
              <div class="logo" style="margin-bottom:12px;">
                ${settings.logo_url ? `<img src="${settings.logo_url}" alt="${escapeHtml(storeName)}">` : '<span class="dot"></span>'}
                ${escapeHtml(storeName)}
              </div>
              <p>${escapeHtml(settings.footer_text || '')}</p>
            </div>
            <div class="footer-col">
              <h4>Loja</h4>
              <a href="/">Início</a>
              <a href="/catalogo">Catálogo</a>
              <a href="/feedbacks">Avaliações</a>
            </div>
            <div class="footer-col">
              <h4>Contato</h4>
              ${settings.email_contact ? `<a href="mailto:${escapeHtml(settings.email_contact)}">${escapeHtml(settings.email_contact)}</a>` : ''}
              ${settings.instagram ? `<a href="https://instagram.com/${escapeHtml(settings.instagram.replace('@',''))}" target="_blank" rel="noopener">@${escapeHtml(settings.instagram.replace('@',''))}</a>` : ''}
              ${settings.whatsapp_number ? `<a href="https://wa.me/${escapeHtml(settings.whatsapp_number)}" target="_blank" rel="noopener">WhatsApp</a>` : ''}
            </div>
          </div>
          <div class="footer-bottom">
            <span>© ${new Date().getFullYear()} ${escapeHtml(storeName)}. Todos os direitos reservados.</span>
            <a href="/admin/login" class="footer-admin-link">Admin</a>
          </div>
        </div>
      </footer>
    `;
  }
}
