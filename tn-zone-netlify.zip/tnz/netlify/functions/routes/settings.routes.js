'use strict';

const express = require('express');
const db = require('../lib/db');
const { asyncHandler } = require('../lib/http-utils');
const { log } = require('../lib/auth');
const { saveBase64Image } = require('../lib/upload');
const { broadcast } = require('../lib/realtime');

const router = express.Router();

router.get(
  '/settings',
  asyncHandler(async (req, res) => {
    const rows = await db.all('SELECT key, value FROM settings');
    const out = {};
    for (const r of rows) out[r.key] = r.value;
    res.status(200).json({ settings: out });
  })
);

router.put(
  '/admin/settings',
  asyncHandler(async (req, res) => {
    const b = req.body;
    await db.tx(async (t) => {
      for (const [k, v] of Object.entries(b)) {
        await t.run(
          'INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value',
          [k, typeof v === 'string' ? v : JSON.stringify(v)]
        );
      }
    });
    await log(req.admin.id, 'settings_update', { keys: Object.keys(b) });
    broadcast('changed', { entity: 'settings' });
    res.status(200).json({ ok: true });
  })
);

// POST /api/admin/upload  { image: "data:image/png;base64,..." }
router.post(
  '/admin/upload',
  asyncHandler(async (req, res) => {
    const b = req.body;
    const { url, publicId } = await saveBase64Image(b.image);
    await log(req.admin.id, 'upload_image', { publicId });
    res.status(201).json({ filename: publicId, url });
  })
);

module.exports = router;
